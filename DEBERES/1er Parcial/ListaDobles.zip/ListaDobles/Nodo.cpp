#pragma once
#include "Nodo.h"
#include <iostream>
#include <conio.h>
#include <stdlib.h>
#include <string.h>

Nodo::Nodo(int _valor, Nodo* _siguiente = NULL, Nodo* _anterior = NULL){
	this-> valor = _valor;
	this-> siguiente = _siguiente;
    this->anterior = _anterior;
}

Nodo::Nodo(){
	
}

Nodo::Nodo(int _valor){
	this-> valor = _valor;
}

void Nodo::setValor(int newValor){
	this-> valor = newValor;
}

int Nodo::getValor(){
	return this->valor;
}

void Nodo::setSiguiente(Nodo* newSiguiente){
	this -> siguiente = newSiguiente;
}

Nodo *Nodo::getSiguiente(){
    return this->siguiente;
}

void Nodo::setAnterior(Nodo* newAnterior){
	this -> anterior = newAnterior;
}

Nodo *Nodo::getAnterior(){
    return this->anterior;
}