#pragma once
#include "Nodo.cpp"
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <string>
#include <string.h>

using namespace std;

class ListaDoble{
	private:
        Nodo* primero;
        Nodo* actual;
	public:
		ListaDoble();
		void insertarCabeza(int);
		void insertarCola(int);
		void insertarPosicion(int, int);
		char *ingresoEntero(const char*);
        int convertirEntero();
		char *ingresoEnteroMenu(const char*);
        int convertirEnteroMenu();
		void buscar(int);
		void mostar();
		void eliminarCola();
		void eliminarCabeza();
		void eliminarNodo(int);
};