
#pragma once
#include <iostream>

class Nodo{
	public:
		Nodo();
		Nodo(int, Nodo*, Nodo*);
		Nodo(int);
		int getValor();
		void setValor(int);
		Nodo *getSiguiente();
		void setSiguiente(Nodo*);
        Nodo *getAnterior();
		void setAnterior(Nodo*);
		friend class Lista;

	private:
		int valor;
		Nodo *siguiente;
		Nodo *anterior;
};